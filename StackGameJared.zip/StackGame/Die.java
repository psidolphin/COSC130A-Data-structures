
import java.util.Random;

/**
 *
 * @author Stephen Fyfe
 */
public class Die {
    int value;
    int sides;
    Random rand;
    
    public Die(){
        value = 1;
        sides = 6;
        rand = new Random();
    }
    
    public Die(int initial) {
        value = 1;
        sides = initial;
        rand = new Random();
    }
    
    public int roll(){
        value = rand.nextInt(sides) + 1;    
        return value;
    }
    
    public int getValue(){
            return value;
    }  
}


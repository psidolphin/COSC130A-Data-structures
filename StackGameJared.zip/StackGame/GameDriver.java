import java.util.Scanner;
/**
 *
 * @author Jared Ren
 */
public class GameDriver {




   public static void main(String[] args) {
      System.out.println("What is the goal score? : ");
      Scanner inputScore = new Scanner(System.in);
      int score = inputScore.nextInt();
      inputScore.nextLine();
      Die firstDie = new Die();
      Die secondDie = new Die();
      int[] playerOneScores = new int[1];
      int[] playerTwoScores = new int[1];
      IntArrayStack dumpyTheDiscardPile = new IntArrayStack();
      
      
      
      
      for(int i = 0; i < 10;  i++){
      //player 1's turn.
         System.out.println("Player 1, what is your selection, 1: roll the die or 2: take what is on top of the discard pile.");
         Scanner selection = new Scanner(System.in);
         int selectionforplayer1 = selection.nextInt();
         selection.nextLine();
         switch(selectionforplayer1){
            case 1: firstDie.roll();
               secondDie.roll();
               System.out.println("player 1, choose one of the values you rolled to keep, the other is discarded");
               System.out.println("the first die value is" + " " + firstDie.value);
               System.out.println("the second die value is" + " " +  secondDie.value);
               System.out.println("1: first die, 2: second die");
               Scanner choice = new Scanner(System.in);
               int answer = choice.nextInt();
               choice.nextLine();
               if(answer == 1){
                  System.out.println("add (1) or subtract value (2) ");
                  Scanner scanny = new Scanner(System.in);
                  int reply = scanny.nextInt();
                  scanny.nextLine();
                  dumpyTheDiscardPile.push(secondDie.value);
                  if(reply == 1){
                     playerOneScores[0] += firstDie.value;
                  }
                  else if(reply == 2){
                     playerOneScores[0] -= firstDie.value;
                  }      
               }
               else if(answer == 2){
                  dumpyTheDiscardPile.push(firstDie.value);
                  System.out.println("add (1) or subtract (2) value");
                  Scanner scanny = new Scanner(System.in);
                  int decide = scanny.nextInt();
                  scanny.nextLine();
                  if(decide == 1){
                     playerOneScores[0] += secondDie.value;
                  }
                  else if(decide == 2){
                     playerOneScores[0] -= secondDie.value;
                  }
                 
               }
               System.out.println("Player 1 current score" + "  " + playerOneScores[0]);
               break;
            case 2:  int playerOneRetrieve = dumpyTheDiscardPile.pop();
               System.out.println("you popped out" + " " + playerOneRetrieve);
               System.out.println("add(1) or subtract(2)");
               Scanner scanathan = new Scanner(System.in);
               int discardchoice = scanathan.nextInt();
               scanathan.nextLine();
               if(discardchoice == 1){
                  playerOneScores[0] += playerOneRetrieve;
               }
               else if(discardchoice == 2){
                  playerOneScores[0] -= playerOneRetrieve;
               }
               System.out.println("Player 1 current score" + "  " + playerOneScores[0]);
               break;
         }
         
         
         
         
         
         
         
         //player 2's turn
         System.out.println("player 2, what is your selection, 1: roll the die or 2: take what is on top of the discard pile.");
         Scanner selection2 = new Scanner(System.in);
         int selectionforplayer2 = selection2.nextInt();
         selection2.nextLine();
         switch(selectionforplayer2){
            case 1: firstDie.roll();
               secondDie.roll();
               System.out.println("the first die value is" + " " + firstDie.value);
               System.out.println("the second die value is" + " " +  secondDie.value);
               System.out.println("player 2, choose one of the values you rolled to keep, the other is discarded");
               System.out.println("die 1 or die 2");
               Scanner scaniel = new Scanner(System.in);
               int answer2 = scaniel.nextInt();
               scaniel.nextLine();
               if(answer2 == 1){
                  dumpyTheDiscardPile.push(secondDie.value);
                  System.out.println("add (1) or subtract value (2) ");
                  Scanner scanriel = new Scanner(System.in);
                  int reply2 = scanriel.nextInt();
                  scanriel.nextLine();
                  if(reply2 == 1){
                     playerTwoScores[0] += firstDie.value;
                  }
                  else if(reply2 == 2){
                     playerTwoScores[0] -= firstDie.value;
                  }
                  else if(answer2 == 2){
                     dumpyTheDiscardPile.push(firstDie.value);
                     System.out.println("add (1) or subtract value (2) ");
                     scanriel = new Scanner(System.in);
                     int decide2 = scanriel.nextInt();
                     scanriel.nextLine();
                     if(decide2 == 1){
                        playerTwoScores[0] += secondDie.value;
                     }
                     else if(decide2 == 2){
                        playerTwoScores[0] -= secondDie.value;
                     }
                  }
               }
               System.out.println("Player 2 current score" + "  " + playerTwoScores[0]);      
               break;
            case 2: int retrievedFromDumpy = dumpyTheDiscardPile.pop();
               System.out.println("you popped out" + " " + retrievedFromDumpy);
               System.out.println("add(1) or subtract(2)");
               Scanner scanriel = new Scanner(System.in);
               int discardchoice2 = scanriel.nextInt();
               scanriel.nextLine();
               if(discardchoice2 == 1){
                  playerTwoScores[0] += retrievedFromDumpy;
               }
               else if(discardchoice2 == 2){
                  playerTwoScores[0] -= retrievedFromDumpy;
               }
               System.out.println("Player 2 current score" + "  " + playerTwoScores[0]);  
               break;
         }
      }
      int diff1 = score - playerOneScores[0];
      int diff2 = score - playerTwoScores[0];
      if(diff1 < 0){
         diff1 *= -1;
      }
      if(diff2 < 0){
         diff2 *= -1;
      }
      if(diff1 < diff2){
         System.out.println("player 1 wins");
      }               
      else if(diff2 < diff1){
         System.out.println("player 2 wins");
      }     
      else{
         System.out.println("It is a draw");
      }   
   
   } 
}
